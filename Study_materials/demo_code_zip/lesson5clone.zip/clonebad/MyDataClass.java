package lesson4.clonebad;

public class MyDataClass implements Cloneable {
	
}
