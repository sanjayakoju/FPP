package lesson4.protectedex.try2.objrefpkg;

import lesson4.protectedex.try2.callingpkg.CallingClass;

public class ObjRefClass extends CallingClass {
	
}
