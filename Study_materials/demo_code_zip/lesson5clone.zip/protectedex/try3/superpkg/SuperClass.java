package lesson4.protectedex.try3.superpkg;

public class SuperClass {
	protected String getVal() {
		return "val";
	}
}
