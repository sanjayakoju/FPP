package lesson4.abstct;

public abstract class MyClass {
	protected abstract int num();
}
