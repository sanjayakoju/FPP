package lesson4.defaultconstructor;

public class Subclass extends MyClass {
	int y = 3;
}
