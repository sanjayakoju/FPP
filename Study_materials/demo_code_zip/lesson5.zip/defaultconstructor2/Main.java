package lesson4.defaultconstructor2;

public class Main {

	public static void main(String[] args) {
		MyClass mc = new Subclass();

	}

}
